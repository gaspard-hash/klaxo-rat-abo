// POST /api/send  { "number": 42 }
// Forwards to the Make webhook stored in the Vercel env var `webhook_make`.
// The URL never reaches the browser: it stays server-side.

const WEBHOOK_URL = process.env.webhook_make || process.env.WEBHOOK_MAKE;

export default async function handler(req, res) {
  if (req.method !== 'POST') {
    res.setHeader('Allow', 'POST');
    return res.status(405).json({ error: 'Méthode non autorisée.' });
  }

  if (!WEBHOOK_URL) {
    return res.status(500).json({
      error: "La variable d'environnement webhook_make n'est pas définie sur ce déploiement.",
    });
  }

  // Vercel parses JSON bodies automatically, but be tolerant if it arrives as a string.
  let body = req.body;
  if (typeof body === 'string') {
    try {
      body = JSON.parse(body);
    } catch {
      return res.status(400).json({ error: 'Corps de requête illisible.' });
    }
  }

  const value = Number(body?.number);
  if (!Number.isFinite(value)) {
    return res.status(400).json({ error: 'Entrez un nombre valide.' });
  }

  try {
    const upstream = await fetch(WEBHOOK_URL, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ number: value, sentAt: new Date().toISOString() }),
    });

    const text = (await upstream.text()).slice(0, 300);

    if (!upstream.ok) {
      return res.status(502).json({
        error: `Make a répondu ${upstream.status}.`,
        detail: text,
      });
    }

    return res.status(200).json({ ok: true, number: value, makeResponse: text });
  } catch (err) {
    return res.status(502).json({ error: `Appel du webhook impossible : ${err.message}` });
  }
}
